import os
import random
import shutil
from pathlib import Path

# 使用相对路径
DATASET_DIR = Path('.')  # 当前目录，即data文件夹
IMAGES_DIR = DATASET_DIR / 'images'
LABELS_DIR = DATASET_DIR / 'labels'
TRAIN_RATIO = 0.8  # 训练集比例

def main():
    # 确保目标目录存在
    os.makedirs(IMAGES_DIR / 'train', exist_ok=True)
    os.makedirs(IMAGES_DIR / 'val', exist_ok=True)
    os.makedirs(LABELS_DIR / 'train', exist_ok=True)
    os.makedirs(LABELS_DIR / 'val', exist_ok=True)
    
    # 获取所有图像文件
    image_files = [f for f in os.listdir(IMAGES_DIR) if f.endswith(('.jpg', '.jpeg', '.png')) and os.path.isfile(os.path.join(IMAGES_DIR, f))]
    
    # 随机打乱图像文件顺序
    random.shuffle(image_files)
    
    # 计算训练集数量
    train_count = int(len(image_files) * TRAIN_RATIO)
    
    # 划分训练集和验证集
    train_images = image_files[:train_count]
    val_images = image_files[train_count:]
    
    print(f"总图像数: {len(image_files)}")
    print(f"训练集图像数: {len(train_images)}")
    print(f"验证集图像数: {len(val_images)}")
    
    # 移动训练集图像和标签
    for img_file in train_images:
        # 处理图像
        src_img = os.path.join(IMAGES_DIR, img_file)
        dst_img = os.path.join(IMAGES_DIR, 'train', img_file)
        shutil.copy2(src_img, dst_img)
        
        # 处理对应的标签（如果存在）
        label_file = os.path.splitext(img_file)[0] + '.txt'
        src_label = os.path.join(LABELS_DIR, label_file)
        if os.path.exists(src_label):
            dst_label = os.path.join(LABELS_DIR, 'train', label_file)
            shutil.copy2(src_label, dst_label)
    
    # 移动验证集图像和标签
    for img_file in val_images:
        # 处理图像
        src_img = os.path.join(IMAGES_DIR, img_file)
        dst_img = os.path.join(IMAGES_DIR, 'val', img_file)
        shutil.copy2(src_img, dst_img)
        
        # 处理对应的标签（如果存在）
        label_file = os.path.splitext(img_file)[0] + '.txt'
        src_label = os.path.join(LABELS_DIR, label_file)
        if os.path.exists(src_label):
            dst_label = os.path.join(LABELS_DIR, 'val', label_file)
            shutil.copy2(src_label, dst_label)
    
    print("数据集分割完成!")

if __name__ == "__main__":
    main() 